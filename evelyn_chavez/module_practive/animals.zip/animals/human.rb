
class Human < Mammal
  # previous code removed for brevity
end
human = Human.new
puts 'I am in the human file'
require_relative 'mammal'
