class HelloController < ApplicationController
    def index
        render :text => "Hello Coding Dojo"
    end
end
