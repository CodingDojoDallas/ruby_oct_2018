require 'test_helper'

class ResultsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
