require 'test_helper'

class NinjasControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
