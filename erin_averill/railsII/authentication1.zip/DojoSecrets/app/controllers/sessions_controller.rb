class SessionsController < ApplicationController
  def new
  end

  def create
  	# User.find_by_email('o@gmail.com').try(:authenticate, 'password')
  	user = User.find_by_email(params[:Email]).try(:authenticate, params[:Password])#User.where(email: params[:email])
  	if user #&& user.authenticate(params[:password])
  		session[:user_id] = user.id
  		redirect_to "/users/#{user.id}"
  	else
  		flash[:errors] = ["Invalid Combination"]
  		redirect_to "/sessions/new"
  	end
  end

  def destroy
  	session[:user_id] = nil
  	redirect_to '/sessions/new'
  end
end
